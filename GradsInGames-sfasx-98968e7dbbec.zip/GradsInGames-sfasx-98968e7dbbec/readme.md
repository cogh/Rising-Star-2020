# SFASX
This is the source for the base project for the Search For A Star & Sumo Digital Rising Star 2020 games programming challenge.

For full details of the project please see your SFASX project brief.

Support: [dan@gradsingames.com](mailto@dan@gradsingames.com)